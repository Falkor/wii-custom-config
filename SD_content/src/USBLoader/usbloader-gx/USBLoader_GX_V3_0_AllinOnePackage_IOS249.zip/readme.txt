USB Loader GX v3.0

For the changes please read the Changelog.txt.

The different versions are only needed on start to read the default 
boot IOS under which the settings are read from USB devices. If you 
choose the correct one and it fits the setting in the settings for 
boot IOS it will speed up the startup process of the Loader. It 
does not server any other purpose!

To use the channel version of the loader or the forwarder channel 
it is required that you install IOS58 on your Wii.
You can use Tantric's safe IOS58 Installer for that.

If you need more information about USB Loader GX you can read up our Wiki page here:
http://code.google.com/p/usbloader-gui/wiki/Introduction