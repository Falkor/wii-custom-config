/*-------------------------------------------------------------
 
setting_replace.c -- setting.txt backup utility
 
Copyright (C) 2008 tona
 
This software is provided 'as-is', without any express or implied
warranty.  In no event will the authors be held liable for any
damages arising from the use of this software.
 
Permission is granted to anyone to use this software for any
purpose, including commercial applications, and to alter it and
redistribute it freely, subject to the following restrictions:
 
1.The origin of this software must not be misrepresented; you
must not claim that you wrote the original software. If you use
this software in a product, an acknowledgment in the product
documentation would be appreciated but is not required.
 
2.Altered source versions must be plainly marked as such, and
must not be misrepresented as being the original software.
 
3.This notice may not be removed or altered from any source
distribution.
 
-------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <gccore.h>
#include <wiiuse/wpad.h>
#include <fat.h>

#include "wiibasics.h"
#include "id.h"

//---------------------------------------------------------------------------------
int main(int argc, char **argv) {
//---------------------------------------------------------------------------------
	u64 tid;
	u32 setting_txt_size, ownerID;
	u16 groupID;
	u8 attr, ownperm, groupperm, otherperm;
	s32 ret;
	static u8 setting_txt[256] ATTRIBUTE_ALIGN(32);
	static char filepath[256] ATTRIBUTE_ALIGN(32);
	FILE *fp = NULL;
	
	ret = 0;
	//ret = IOS_ReloadIOS(249);
	basicInit();
	
	/* PART 1
		Show IOS, set UID, Start ISFS, Identify, get title ID, get data dir */
	printf("\n\tIOS: %d\n", IOS_GetVersion());
	
	Identify_SU();
	
	ret = ES_SetUID(TITLE_ID(1, 2));
	if (ret < 0){
		printf("SetUID fail %d", ret);
		wait_anyKey();
	}	
	
	ret = ES_GetTitleID(&tid);
	if (ret < 0){
		printf("\tTitleFail! %d\n", ret);
	} 
	
	if (tid != TITLE_ID(1,2)){
		printf("Not System Menu! Quitting!\n");
		exit(1);
	}
	
	printf("\n\tInitializing Filesystem driver...");
	fflush(stdout);
	
	ret = ISFS_Initialize();
	if (ret < 0) {
		printf("\n\tError! ISFS_Initialize (ret = %d)\n", ret);
		wait_anyKey();
	} else {
		printf("OK!\n");
	}
	
	if (ES_GetDataDir(tid, filepath) < 0){
			printf("\tWe can't get it up! %d\n", ret);
			exit(1);
		}
	strcat(filepath, "/setting.txt");
	
	wait_anyKey();
	printf("\x1b[2J\n\n");
	
	if (!fatInitDefault()){
		printf("Failed to init FAT!\n");
		exit(1);
	}
	
	fp = fopen("setting.txt", "r");
	if (fp){
		printf("setting.txt found!\n");
		fseek(fp, 0, SEEK_END);
		if (ftell(fp) != 256){
			printf("Wrong size! %ld\n", ftell(fp));
			exit(1);
		}
		fseek(fp, 0, SEEK_SET);
		fread(setting_txt, 1, 256, fp);
		fclose(fp);
		printf("Replace setting.txt with SD card setting.txt?\n");
		if (yes_or_no()) {
			ret = ISFS_GetAttr(filepath,  &ownerID, &groupID, &attr, &ownperm, &groupperm, &otherperm);
			if (ret < 0){
				printf("\tFail! %d\n", ret);
				attr = 0;
				ownperm = groupperm = otherperm = 1;
				exit(1);
			}
			
			ret = ISFS_WriteFileFromArray(filepath, setting_txt, 256, ownerID, groupID, attr, ownperm, groupperm, otherperm);
			if (ret < 0){
				printf("\tFail! %d\n", ret);
				wait_anyKey();
				exit(1);
			}
		
			ret = ISFS_GetAttr(filepath,  &ownerID, &groupID, &attr, &ownperm, &groupperm, &otherperm);
			if (ret < 0){
				printf("\tFail! %d\n", ret);
			}
		
			wait_anyKey(); 
		}
	} else {
		printf("setting.txt not found\n");
	}
	printf("Backup setting.txt to SD card?\n");
	if (yes_or_no()){
		printf("Backing up...");
		
		if (ISFS_ReadFileToArray (filepath, setting_txt, 256, &setting_txt_size) < 0){
			printf("Failed to read real setting.txt!\n");
			exit(1);
		}
		fp = fopen("setting.txt", "w");
		if (!fp){
			printf("Failed to open setting.txt for writing!\n");
			exit(1);
		}
		fseek(fp, 0, SEEK_SET);
		fwrite(setting_txt, 1, 256, fp);
		fclose(fp);
		printf("Done!\n");
	}
	
	
	printf("Press any key to quit.");
	wait_anyKey();
	miscDeInit();

	return 0;
}
