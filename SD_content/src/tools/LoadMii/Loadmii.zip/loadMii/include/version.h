#ifndef _loadMii_version
#define _loadMii_version

#define loadmiiVersionMajor '0'
#define loadmiiVersionMinor '4'
#define loadmiiVersionPatch '0'

#endif
